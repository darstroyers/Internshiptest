package com.example.testintern2

import android.annotation.SuppressLint
import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class MyAdapter(private val context: Activity, private val arrayList: MutableList<item>)
    : ArrayAdapter<item>(context, R.layout.listview, arrayList) {
    @SuppressLint("ViewHolder", "InflateParams")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val inflater : LayoutInflater = LayoutInflater.from(context)
        val view : View = inflater.inflate(R.layout.listview, null)

        val imageView : ImageView = view.findViewById(R.id.image)
        val username : TextView = view.findViewById(R.id.Name)
        val address: TextView = view.findViewById(R.id.Address)

        imageView.setImageResource(arrayList[position].imageId)
        username.text = arrayList[position].name
        address.text = arrayList[position].address

        return view
    }
}
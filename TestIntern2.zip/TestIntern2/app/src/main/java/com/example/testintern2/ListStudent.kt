package com.example.testintern2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class ListStudent : AppCompatActivity() {

//    private lateinit var binding: ActivityMainBinding
//    private lateinit var userArrayList : ArrayList<item>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_student)
//        binding = ActivityMainBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        val imageId = intArrayOf(
//
//            R.drawable.boy1,
//            R.drawable.girl1,
//            R.drawable.boy2,
//            R.drawable.girl2,
//            R.drawable.boy3,
//            R.drawable.girl3,
//            R.drawable.boy4,
//            R.drawable.girl4,
//            R.drawable.boy5,
//            R.drawable.girl5,
//
//        )
//
//        val name = arrayOf(
//
//            "Reyes",
//            "Alyce",
//            "Russel",
//            "Mallory",
//            "Moshe",
//            "Jolene",
//            "Brian",
//            "Isabel",
//            "Marcellus",
//            "Dina"
//        )
//
//        val address = arrayOf(
//
//            "Ki. Jared no 19, Suite 951, 38786, Lumajang",
//            "Gg. D'Amore no 29, Suite 953, 49702, Bangli",
//            "Jr. Martina no 10, Apt. 935, 63943, Indramayu",
//            "Jr. Larkin no 1, Apt. 191, 84023, Palu, Banten, Indonesia",
//            "Jln. Kreiger no 4, Suite 788, 66201, Batanga",
//            "Psr. Dietrich no 04, Apt. 960, 80492, Klungkung",
//            "Psr. Orn no 3, Apt. 938, 10280, Malang",
//            "Psr. Jennings no 29, Apt. 593, 37999, Cikampek",
//            "Kpg. Rice no 03, Suite 406, 18241, Bulukumba",
//            "Jr. Bergstrom no 1, Apt. 965, 35987, Luwuk"
//        )
//
//        userArrayList = ArrayList()
//        for(i in name.indices) {
//            val listitem = item(name[i], address[i], imageId[i])
//            userArrayList.add(listitem)
//        }

         val myListData= mutableListOf<item>()
        myListData.add(item("Reyes", "Ki. Jared no 19, Suite 951, 38786, Lumajang", R.drawable.boy1))
        myListData.add(item("Alyce", "Gg. D'Amore no 29, Suite 953, 49702, Bangli", R.drawable.girl1))
        myListData.add(item("Russel", "Jr. Martina no 10, Apt. 935, 63943, Indramayu", R.drawable.boy2))
        myListData.add(item("Mallory", "Jr. Larkin no 1, Apt. 191, 84023, Palu, Banten, Indonesia", R.drawable.girl2))
        myListData.add(item("Moshe", "Jln. Kreiger no 4, Suite 788, 66201, Batanga", R.drawable.boy3))
        myListData.add(item("Jolene", "Psr. Dietrich no 04, Apt. 960, 80492, Klungkung", R.drawable.girl3))
        myListData.add(item("Brian", "Psr. Orn no 3, Apt. 938, 10280, Malang", R.drawable.boy6))
        myListData.add(item("Isabel", "Psr. Jennings no 29, Apt. 593, 37999, Cikampek", R.drawable.girl4))
        myListData.add(item("Marcellus", "Kpg. Rice no 03, Suite 406, 18241, Bulukumba", R.drawable.boy7))
        myListData.add(item("Dina", "Jr. Bergstrom no 1, Apt. 965, 35987, Luwuk", R.drawable.girl5))



        val myListView = findViewById<ListView>(R.id.mylistview)
        myListView.adapter = MyAdapter(this, myListData)
    }
}
package com.example.testintern2

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.testintern2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {
            if (binding.username.text.isEmpty() && binding.password.text.isEmpty()){
                Toast.makeText(this, "Username & Password must be filled!!", Toast.LENGTH_SHORT).show()
            } else if (binding.username.text.isEmpty()) {
                Toast.makeText(this, "Username must be filled!!", Toast.LENGTH_SHORT).show()
            }else if (binding.password.text.isEmpty()){
                Toast.makeText(this, "Password must be filled!!", Toast.LENGTH_SHORT).show()
            } else if (binding.username.text.toString() == "alfagift-admin" && binding.password.text.toString() == "asdf") {
                startActivity(Intent(this, ListStudent::class.java))
            } else {
                Toast.makeText(this, "Username or password is incorrect.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.google.setOnClickListener {
            val opengoogle = Intent(Intent.ACTION_VIEW)
            opengoogle.data = Uri.parse("https://www.google.com/")

            startActivity(opengoogle)
        }
    }

}
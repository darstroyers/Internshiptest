package com.example.testintern2

data class item(var name: String, var address: String, var imageId: Int)
